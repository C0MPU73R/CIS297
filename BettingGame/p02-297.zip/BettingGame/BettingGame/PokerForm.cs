﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BettingGame
{
    public partial class PokerForm : Form
    {
        private Image[] arrayOfPokerImages;
        public PokerForm()
        {
            InitializeComponent();
        }

        private void PokerForm_Load(object sender, EventArgs e)
        {


        }
    }
}
